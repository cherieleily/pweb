<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Login extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    public function register()
    {
        $data['title'] = 'Register';


        $this->load->view('_layout/auth-header', $data);
        $this->load->view('element/page/register', $data);
        $this->load->view('_layout/auth-footers', $data);
    }

    public function index()
    {
        $data['title'] = 'Login';


        $this->load->view('_layout/auth-header', $data);
        $this->load->view('element/page/login', $data);
        $this->load->view('_layout/auth-footers', $data);
    }

    public function blank()
    {
        $data['title'] = 'Blank';


        $this->load->view('_layout/header', $data);
        $this->load->view('_layout/sidebar', $data);
        $this->load->view('_layout/topbar', $data);
        $this->load->view('element/page/blank', $data);
        $this->load->view('_layout/footer');
    }

    public function error_page()
    {
        $data['title'] = '404 Page';


        $this->load->view('_layout/header', $data);
        $this->load->view('_layout/sidebar', $data);
        $this->load->view('_layout/topbar', $data);
        $this->load->view('element/page/404', $data);
        $this->load->view('_layout/footer');
    }

    
}
