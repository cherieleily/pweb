<html>
<head>
    <title>Form Tambah Data</title>
</head>
<body>
    <h1>Form Tambah Data</h1>
    <hr>
    <button onclick="document.location.href='<?php echo site_url();?>/home/index'">Kembali</button>
    <hr>
    <form action="<?php echo site_url();?>/home/simpandata" method="post">
        <table>
            <tr>
                <td>Nama Anggota</td>
                <td><input type="text" name="nama"</td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td><input type="text" name="alamat"</td>
            </tr>
            <tr>
                <td>Telepon</td>
                <td><input type="text" name="telepon"</td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit"</td>
            </tr>
</body>
</html>