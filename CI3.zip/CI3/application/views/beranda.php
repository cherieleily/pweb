<html>
    <head>
        <script>
            function hapus(id) {
                var jawab = confirm("Data mau dihapus?");
            if (jawab) {
                document.location.href="<?php echo site_url();?>/home/hapusdata/"+id;
                }
            }
            </script>
    </head>
    <body>
        <h1>Hello</h1>
        <button onclick="document.location.href='<?php echo site_url();?>/home/tambahdata'">Tambah</button>
        <hr>
        <table>
            <tr>
                <th>No</th>
                <th>ID</th>
                <th>Nama Anggota</th>
                <th>Alamat</th>
                <th>Telepon</th>
                <th>Aksi</th>
            </tr>
        <?php
            $no = 1;
            foreach ($anggota as $ang) {
        ?>
            <tr>
                <td><?=$no?></td>
                <td><?=$ang->IDAnggota?></td>
                <td><?=$ang->NamaAnggota?></td>
                <td><?=$ang->Alamat?></td>
                <td><?=$ang->Telepon?></td>
                <td>
                    <button onclick ="document.location.href='<?php echo site_url();?>/home/editdata/<?=$ang->IDAnggota?>'">Edit</button>
                    <button onclick ="hapus('<?=$ang->IDAnggota?>');">Hapus</button>
                </td>
            </tr>
        <?php 
            $no++;
            } 
        ?>

        </table>
    </body>
</html>