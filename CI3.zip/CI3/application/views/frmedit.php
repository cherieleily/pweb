<html>
<head>
    <title>Form Edit Data</title>
</head>
<body>
    <h1>Form Edit Data</h1>
    <hr>
    <button onclick="document.location.href='<?php echo site_url();?>/home/index'">Kembali</button>
    <hr>
    <form action="<?php echo site_url();?>/home/update" method="post">
        <table>
            <tr>
                <td>Nama Anggota</td>
                <td><input type="text" name="id" value="<?=$anggota->IDAnggota?>" hidden> 
                <td><input type="text" name="nama" value="<?=$anggota->NamaAnggota?>"</td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td><input type="text" name="alamat" value="<?=$anggota->Alamat?>"</td>
            </tr>
            <tr>
                <td>Telepon</td>
                <td><input type="text" name="telepon" value="<?=$anggota->Telepon?>"</td>
            </tr>
            <tr>
                <td></td>
                <td><input type="Update"</td>
            </tr>
</body>
</html>