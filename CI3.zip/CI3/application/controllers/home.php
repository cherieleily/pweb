<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class home extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->
		model("anggota_model");
        
    }

    public function index()
    {
        $data["anggota"] = $this-> anggota_model->getAll();
        $this->load->
		view('beranda', $data);
    }

    public function tambahdata()
    {
        $this->load->
		view('frmtambahdata');
    }
    public function simpandata()
    {
        $anggota = $this->anggota_model;
        $anggota->save();
        $data["anggota"] = $this ->
            anggota_model->getAll();
        $this->load->
		view('beranda', $data);
    }
    public function editdata()
    {
        $id = $this->uri->segment(3);
        $data["anggota"]=$this->
            anggota_model->getById($id);
        $this->load->
		view('frmedit', $data);
    }
    public function hapusdata()
    {
        $id = $this->uri->segment(3);
        $anggota = $this->anggota_model;
        $anggota->delete($id);

        $data["anggota"] = $this->
            anggota_model->getAll();
        $this->load->
		view('beranda',$data);
    }

    public function update()
    {
        $anggota = $this->anggota_model;
        $anggota->update();
        $data["anggota"] = $this ->
            anggota_model->getAll();
        $this->load->
		view('beranda', $data);
    }

}
