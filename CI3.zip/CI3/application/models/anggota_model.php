<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class anggota_model extends CI_Model {
    private $tabel = 'tbanggota';

    public $idanggota, 
           $namaanggota, 
           $alamat, 
           $telepon;

    public function rules()
	{
		return [
            ['field' => 'nama',
            'label' => 'Nama Anggota',
            'rules' => 'required']
        ];
	}

    public function getAll(){
        return $this->db->
        get ($this->tabel)->result();
    }

    public function getById($id)
    {
        return $this->db->
        get_where ($this->tabel, ["IDAnggota"=> $id])-> row();
    }

    public function save()
    {
        $post = $this->input->post();
        $this->idanggota = uniqid();
        $this->namaanggota = $post["nama"];
        $this->alamat = $post["alamat"];
        $this->telepon = $post["telepon"];
        return $this->db->insert($this->tabel, $this);
    }

    public function update()
    {
        $post = $this->input->post();
        $data = array(
            'namaanggota' => $post["nama"],
            'alamat' => $post["alamat"],
            'telepon' => $post["telepon"]
        );
            return $this->db->
                update($this->tabel, $data,
                array('IDAnggota' =>$post['id']));
    }

    public function delete($id)
    {
        return $this->db->
        delete($this->tabel, 
        array("IDAnggota" => $id));
    }
}